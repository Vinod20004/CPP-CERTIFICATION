#include<iostream>
using namespace std;
class A{
	public:
	   A()
	   {
	   	cout<<"A constructor in action:"<<endl;
	   }
};
int main(){
	A a1;
	return 0;
}
